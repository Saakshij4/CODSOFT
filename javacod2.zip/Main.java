import java.util.*;

public class Main{

	public static float calculatingAverage(int marks[], int numberOfSubjects) {
		
		int totalMarks=0;
		for(int i=0;i<numberOfSubjects;i++){
		    totalMarks+=marks[i];
		}
		    float avgPrecentage=totalMarks/numberOfSubjects;
		    return avgPrecentage;
		
	}
		
		public static char calculateGrade(float avgPrecentage){
		    
		    if(avgPrecentage>=90 && avgPrecentage<100){
		        return 'A';
		    }
		    if(avgPrecentage>=80 && avgPrecentage<90){
		        return 'A';
		    }
		    if(avgPrecentage>=70 && avgPrecentage<80 ){
		        return 'B';
		    }
		    if(avgPrecentage>=60 && avgPrecentage<70){
		        return 'C';
		    }
		    if(avgPrecentage>=60 && avgPrecentage<70){
		        return 'D';
		    }
		    if(avgPrecentage>=50 && avgPrecentage<60){
		        return 'E';
		    }
		    if(avgPrecentage>=40 && avgPrecentage<50){
		        return 'E';
		    }
		    else{
		        return 'F';
		    }
		}
		
		public static void main(String [] args){
		    Scanner sc=new Scanner(System.in);
		    System.out.print("Enter number of subjects: ");
            int numberOfSubjects = sc.nextInt();
            
		    int marks[]=new int [numberOfSubjects];
		    System.out.println("Enter the marks of each subject out of 100: ");
		    for(int i=1;i<numberOfSubjects;i++){
		        System.out.println("The mark of subject "+i+" : ");
		        int mark=sc.nextInt();
		        if(0 <= mark && mark <= 100){
		        marks[i]=mark;
		        }
		        else{
                System.out.println("Please enter marks in range 0 to 100!");
                System.exit(0);
            }    
            System.out.println();
        }

        float averagePercentage = calculatingAverage(marks, numberOfSubjects);

        System.out.println("\nThe Average Percentage is: " + averagePercentage);
        System.out.println("The Grade obtained is: " + calculateGrade(averagePercentage));
		        
		    }
		}
	
